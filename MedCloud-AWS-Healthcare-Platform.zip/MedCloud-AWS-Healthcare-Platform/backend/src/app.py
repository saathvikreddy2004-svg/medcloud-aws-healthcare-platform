import json, os, uuid
from datetime import datetime, timezone
import boto3

db=boto3.resource("dynamodb")
patients=db.Table(os.environ["PATIENTS_TABLE"])
appointments=db.Table(os.environ["APPOINTMENTS_TABLE"])

def response(code,body):
    return {"statusCode":code,"headers":{"Content-Type":"application/json","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Authorization,Content-Type","Access-Control-Allow-Methods":"GET,POST,OPTIONS"},"body":json.dumps(body,default=str)}

def claims(event):
    return event.get("requestContext",{}).get("authorizer",{}).get("jwt",{}).get("claims",{})

def handler(event,context):
    method=event.get("requestContext",{}).get("http",{}).get("method","GET")
    path=event.get("rawPath","/")
    if method=="OPTIONS": return response(204,{})
    c=claims(event)
    user=c.get("sub","demo-user")
    groups=c.get("cognito:groups","")
    if path.endswith("/health"): return response(200,{"status":"healthy","service":"MedCloud"})
    if method=="GET" and path.endswith("/patients"):
        return response(200,{"items":patients.scan().get("Items",[]),"requestedBy":user})
    if method=="POST" and path.endswith("/appointments"):
        body=json.loads(event.get("body") or "{}")
        item={"id":uuid.uuid4().hex,"patientId":body.get("patientId",user),"doctorId":body.get("doctorId"),"date":body.get("date"),"status":"Scheduled","createdAt":datetime.now(timezone.utc).isoformat()}
        appointments.put_item(Item=item); return response(201,item)
    if method=="GET" and path.endswith("/appointments"):
        return response(200,{"items":appointments.scan().get("Items",[])})
    return response(404,{"message":"Route not found"})
