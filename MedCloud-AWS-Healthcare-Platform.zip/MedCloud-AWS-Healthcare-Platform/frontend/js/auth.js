document.getElementById("loginForm")?.addEventListener("submit",async e=>{
 e.preventDefault();
 document.getElementById("msg").textContent="Connect this form to Amazon Cognito using your User Pool/App Client. Demo dashboards are available from the links above.";
});