# MedCloud — Advanced AWS Healthcare Management Platform

A portfolio-ready healthcare cloud platform demonstrating secure, serverless AWS architecture for **synthetic/demo healthcare data**.

> This is an educational portfolio project. It is not a clinical system and must not be used with real patient/PHI data without appropriate professional, legal, security, privacy, and compliance controls.

## Features

### Authentication
- Amazon Cognito User Pool
- Admin / Doctor / Patient roles
- JWT-protected API Gateway
- Role-aware dashboards

### Doctor
- Patient list
- Patient medical timeline
- Appointments
- Vitals
- Prescriptions
- Lab-report metadata

### Patient
- Personal dashboard
- Attendance/visit-style health timeline
- Appointments
- Prescriptions
- Vitals charts
- Secure document/report area

### Admin
- User/role overview
- Department statistics
- Appointment analytics
- Audit-oriented activity view

### AWS
- Amazon S3 + CloudFront
- Amazon Cognito
- API Gateway
- AWS Lambda
- DynamoDB
- AWS HealthLake/FHIR R4 integration path
- S3 for reports/documents
- CloudWatch
- CloudTrail
- KMS
- IAM
- Secrets Manager
- AWS SAM
- GitHub Actions

AWS HealthLake provides a managed FHIR R4 data store and supports FHIR REST APIs, search, versioning and bulk export. https://docs.aws.amazon.com/healthlake/latest/devguide/what-is.html

## Architecture

See `docs/aws-architecture.svg`.

```text
Patients / Doctors / Admin
          |
          v
     CloudFront
          |
          +------> S3 Static Frontend
          |
          v
       Cognito
     Login + JWT
          |
          v
     API Gateway
          |
          v
       Lambda
     /     |      \
    v      v       v
DynamoDB  S3    HealthLake
 App DB   Files   FHIR R4
    |
    v
CloudWatch / CloudTrail
```

AWS's serverless multi-tier pattern uses Cognito authentication, API Gateway, Lambda and purpose-built data stores such as DynamoDB. This project follows that pattern and adds healthcare-specific FHIR/HealthLake integration. https://docs.aws.amazon.com/whitepapers/latest/serverless-multi-tier-architectures-api-gateway-lambda/web-application.html

## Project structure

```text
MedCloud-AWS-Healthcare-Platform/
├── frontend/
│   ├── index.html
│   ├── admin.html
│   ├── doctor.html
│   ├── patient.html
│   ├── css/style.css
│   └── js/
│       ├── config.js
│       ├── auth.js
│       └── dashboard.js
├── backend/
│   ├── src/app.py
│   └── requirements.txt
├── infrastructure/
│   └── template.yaml
├── docs/
│   ├── aws-architecture.svg
│   ├── HEALTHLAKE-SETUP.md
│   └── SECURITY.md
├── sample-data/
│   └── synthea-patient.json
├── .github/workflows/deploy.yml
├── .gitignore
└── README.md
```

## Deployment

### 1. AWS prerequisites

Install:
- AWS CLI
- AWS SAM CLI
- Python 3.12+

Configure your AWS profile:

```bash
aws configure
```

### 2. Deploy serverless backend

```bash
cd infrastructure
sam build
sam deploy --guided
```

The stack creates the Cognito user pool, Cognito groups, API Gateway, Lambda function and DynamoDB tables.

### 3. Configure frontend

Copy the stack outputs into:

```text
frontend/js/config.js
```

Do not commit secrets.

### 4. HealthLake

HealthLake is intentionally documented as an integration layer rather than blindly created by the basic SAM stack. Follow `docs/HEALTHLAKE-SETUP.md`.

HealthLake supports FHIR R4 and can import FHIR data from Amazon S3. AWS also provides a Synthea preload option for creating synthetic health data. https://docs.aws.amazon.com/healthlake/latest/devguide/managing-data-stores-create.html

### 5. Frontend

Upload the `frontend/` directory to a private S3 bucket and serve it through CloudFront. For production, use CloudFront Origin Access Control rather than public S3 access.

## Demo accounts

Create your own Cognito users and assign them to:
- `Admin`
- `Doctor`
- `Patient`

Never put real passwords in this repository.

## Healthcare data model

The project uses a simplified application layer for demo workflows and provides an integration path to FHIR R4.

Example resources:
- Patient
- Practitioner
- Encounter
- Observation
- MedicationRequest
- DiagnosticReport
- Appointment

HealthLake supports FHIR R4 resources through standard FHIR REST interactions. https://docs.aws.amazon.com/healthlake/latest/devguide/managing-fhir-resources.html

## AI extension

A future module can connect authorized clinical context to Amazon Bedrock for:
- medical-record summarization
- administrative note summarization
- patient-question drafting

Any AI feature should use synthetic data for this portfolio project and include human review. It must not be presented as autonomous diagnosis or treatment.

## Security

- Synthetic data only
- Cognito authentication
- JWT validation
- IAM least privilege
- KMS encryption
- CloudTrail auditing
- CloudWatch logging
- Secrets Manager for secrets
- Private S3 + CloudFront
- WAF/rate limiting recommended
- No credentials or `.pem` files in Git

## Resume description

**MedCloud — AWS Healthcare Management Platform**

> Built a secure serverless healthcare management platform using Amazon Cognito, API Gateway, Lambda, DynamoDB, S3 and CloudFront, with FHIR R4/HealthLake integration architecture. Implemented role-based Admin, Doctor and Patient dashboards, healthcare records, appointments, vitals analytics, audit-oriented logging, Infrastructure as Code using AWS SAM, and GitHub Actions CI/CD.

## Important disclaimer

AWS HealthLake is a healthcare data service, but using an AWS service that is eligible for healthcare workloads does not automatically make an application compliant. Real healthcare deployment requires appropriate architecture, configuration, policies, contracts, risk controls and professional review.
