# Security Checklist

- Use synthetic healthcare data only.
- Do not commit AWS access keys.
- Do not commit Cognito passwords.
- Do not commit `.pem` files.
- Use Cognito JWT authentication.
- Use IAM least privilege.
- Use KMS for encryption where required.
- Keep S3 private and use CloudFront Origin Access Control.
- Enable CloudTrail.
- Enable CloudWatch logging and alarms.
- Use Secrets Manager for application secrets.
- Add AWS WAF for internet-facing production workloads.
- Review healthcare privacy/compliance requirements with qualified professionals before using real PHI.
- Treat AI output as assistive only and require human review for clinical use.
