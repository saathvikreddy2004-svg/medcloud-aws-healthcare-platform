# AWS HealthLake Integration

HealthLake is an optional healthcare data layer for this portfolio project.

## Why HealthLake?

AWS HealthLake provides a managed FHIR R4 data store. It supports FHIR REST APIs for creating, reading, updating and searching healthcare resources.

## Suggested demo workflow

1. Create a HealthLake FHIR R4 data store.
2. Use synthetic Synthea data only.
3. Import FHIR JSON/NDJSON from S3.
4. Connect the backend to authorized FHIR endpoints.
5. Use Patient, Observation, Encounter, MedicationRequest and DiagnosticReport resources.
6. Keep application metadata such as UI preferences and appointment workflow data in DynamoDB.

AWS documentation:
https://docs.aws.amazon.com/healthlake/latest/devguide/what-is.html
https://docs.aws.amazon.com/healthlake/latest/devguide/managing-fhir-resources.html

Do not upload real patient information to this GitHub project.
